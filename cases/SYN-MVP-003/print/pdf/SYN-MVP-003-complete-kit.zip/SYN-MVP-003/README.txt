PROJECT SYNAPSE - Case 03: The Ashcombe Dome

COMPLETE KIT. This zip contains the sealed pages: the Authority results, the Reconsider
inserts and Envelope S-1 (the solution). If you want to play, let someone else open it.

You need: 41 A4 sheets, and 16 envelopes: 10 numbered 01-10, 5 marked RECONSIDER, 1 marked S-1.
Print on A4, default margins, 100% scale. PRINT-GUIDE.md explains every step.
