PROJECT SYNAPSE - Case 03: The Ashcombe Dome

PLAYER FILES. Nothing in this zip spoils the case. The sealed pages are in the complete kit.

You need: 41 A4 sheets, and 16 envelopes: 10 numbered 01-10, 5 marked RECONSIDER, 1 marked S-1.
Print on A4, default margins, 100% scale. PRINT-GUIDE.md explains every step.
