PROJECT SYNAPSE - Case 02: The Ravensgate Interlock

COMPLETE KIT. This zip contains the sealed pages: the Authority results, the Reconsider
inserts and Envelope S-1 (the solution). If you want to play, let someone else open it.

You need: 53 A4 sheets (55 for 2-4 players, 56 for 5-6), and 17 envelopes: 12 numbered 01-12, 4 marked RECONSIDER, 1 marked S-1. Plus clips for the five file bundles..
Print on A4, default margins, 100% scale. PRINT-GUIDE.md explains every step.
