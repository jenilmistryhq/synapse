PROJECT SYNAPSE - Case 00: The Consignment Watch

COMPLETE KIT. This zip contains the sealed pages: the Authority results, the Reconsider
inserts and Envelope S-1 (the solution). If you want to play, let someone else open it.

You need: 22 A4 sheets, and 9 envelopes: 6 numbered 01-06, 2 marked RECONSIDER, 1 marked S-1.
Print on A4, default margins, 100% scale. PRINT-GUIDE.md explains every step.
