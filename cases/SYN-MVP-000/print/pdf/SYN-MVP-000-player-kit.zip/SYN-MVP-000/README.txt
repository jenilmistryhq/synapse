PROJECT SYNAPSE - Case 00: The Consignment Watch

PLAYER FILES. Nothing in this zip spoils the case. The sealed pages are in the complete kit.

You need: 22 A4 sheets, and 9 envelopes: 6 numbered 01-06, 2 marked RECONSIDER, 1 marked S-1.
Print on A4, default margins, 100% scale. PRINT-GUIDE.md explains every step.
