PROJECT SYNAPSE - Case 01: The Halvorsen Bequest

COMPLETE KIT. This zip contains the sealed pages: the Authority results, the Reconsider
inserts and Envelope S-1 (the solution). If you want to play, let someone else open it.

You need: 33 A4 sheets (36 for 2-3 players, 40 for 4-6), and 15 envelopes: 11 numbered 01-11, 3 marked RECONSIDER, 1 marked S-1.
Print on A4, default margins, 100% scale. PRINT-GUIDE.md explains every step.
